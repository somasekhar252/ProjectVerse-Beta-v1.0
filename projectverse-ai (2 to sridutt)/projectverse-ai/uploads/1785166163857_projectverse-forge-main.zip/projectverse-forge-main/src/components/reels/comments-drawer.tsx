import { useState } from "react";
import { Drawer } from "./drawer";
import type { Reel } from "@/lib/reels-data";
import { Heart, Send, Pin } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatCount } from "@/lib/format";

type Comment = {
  id: string;
  author: string;
  handle: string;
  color: string;
  text: string;
  likes: number;
  liked: boolean;
  pinned?: boolean;
  time: string;
};

const SEED: Comment[] = [
  {
    id: "c1",
    author: "Aditi Sharma",
    handle: "aditi.dev",
    color: "#7c3aed",
    text: "This is exactly the project I wanted to build this semester. The architecture explanation was 🔥",
    likes: 342,
    liked: false,
    pinned: true,
    time: "2h",
  },
  {
    id: "c2",
    author: "Rohan Gupta",
    handle: "rohan.builds",
    color: "#ec4899",
    text: "Curious — how did you handle offline sync when the bus is out of network?",
    likes: 84,
    liked: false,
    time: "5h",
  },
  {
    id: "c3",
    author: "Sneha Iyer",
    handle: "sneha.codes",
    color: "#22c55e",
    text: "The folder structure is very clean, saving this for my project.",
    likes: 51,
    liked: false,
    time: "1d",
  },
];

export function CommentsDrawer({
  reel,
  open,
  onClose,
}: {
  reel: Reel | null;
  open: boolean;
  onClose: () => void;
}) {
  const [comments, setComments] = useState<Comment[]>(SEED);
  const [input, setInput] = useState("");

  const add = () => {
    const t = input.trim();
    if (!t) return;
    setComments((c) => [
      {
        id: `c_${Date.now()}`,
        author: "You",
        handle: "you",
        color: "#f59e0b",
        text: t,
        likes: 0,
        liked: false,
        time: "now",
      },
      ...c,
    ]);
    setInput("");
  };

  const like = (id: string) =>
    setComments((c) =>
      c.map((x) =>
        x.id === id
          ? { ...x, liked: !x.liked, likes: x.liked ? x.likes - 1 : x.likes + 1 }
          : x,
      ),
    );

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={reel ? `${formatCount(reel.stats.comments)} comments` : "Comments"}
      side="bottom"
    >
      <div className="flex h-full flex-col">
        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
          {comments.map((c) => (
            <div key={c.id} className="flex items-start gap-3 animate-fade-in-up">
              <div
                className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-xs font-bold text-white"
                style={{ backgroundColor: c.color }}
              >
                {c.author
                  .split(" ")
                  .map((s) => s[0])
                  .join("")}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{c.author}</span>
                  <span className="text-xs text-muted-foreground">@{c.handle}</span>
                  <span className="text-xs text-muted-foreground">· {c.time}</span>
                  {c.pinned && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-semibold text-primary">
                      <Pin className="h-2.5 w-2.5" /> Pinned
                    </span>
                  )}
                </div>
                <p className="mt-1 text-sm leading-relaxed">{c.text}</p>
                <div className="mt-1.5 flex items-center gap-4">
                  <button
                    onClick={() => like(c.id)}
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                  >
                    <Heart
                      className={cn("h-3.5 w-3.5", c.liked && "fill-rose-500 text-rose-500")}
                    />
                    {c.likes}
                  </button>
                  <button className="text-xs text-muted-foreground hover:text-foreground">
                    Reply
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            add();
          }}
          className="flex items-center gap-2 border-t border-border/60 bg-card px-5 py-3"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Add a comment…"
            className="flex-1 rounded-full border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="grid h-10 w-10 place-items-center rounded-full gradient-brand text-white shadow-glow disabled:opacity-40"
            aria-label="Send comment"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </Drawer>
  );
}
