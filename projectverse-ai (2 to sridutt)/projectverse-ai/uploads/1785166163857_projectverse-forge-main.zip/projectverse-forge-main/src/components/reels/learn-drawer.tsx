import { useEffect, useRef, useState } from "react";
import type { Reel } from "@/lib/reels-data";
import { Drawer } from "./drawer";
import {
  Sparkles,
  Layers,
  FolderTree,
  HelpCircle,
  Brain,
  Zap,
  ExternalLink,
  Check,
  Send,
  Trophy,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useReelsStore } from "@/lib/reels-store";
import { toast } from "sonner";

type Props = {
  reel: Reel | null;
  open: boolean;
  onClose: () => void;
};

const TABS = [
  { id: "explain", label: "AI Explain", icon: Sparkles },
  { id: "arch", label: "Architecture", icon: Layers },
  { id: "stack", label: "Tech Stack", icon: Zap },
  { id: "folders", label: "Folders", icon: FolderTree },
  { id: "interview", label: "Interview", icon: HelpCircle },
  { id: "quiz", label: "Quiz", icon: Brain },
  { id: "related", label: "Related", icon: ExternalLink },
  { id: "ask", label: "Ask AI", icon: Send },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function LearnDrawer({ reel, open, onClose }: Props) {
  const [tab, setTab] = useState<TabId>("explain");

  useEffect(() => {
    if (open) setTab("explain");
  }, [open, reel?.id]);

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={reel ? `Learn · ${reel.title}` : "Learn"}
      widthClass="md:max-w-2xl"
    >
      {reel && (
        <div className="flex h-full flex-col">
          <div className="scrollbar-hide flex gap-1.5 overflow-x-auto border-b border-border/60 px-4 py-3">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all",
                    active
                      ? "gradient-brand text-white shadow-glow"
                      : "bg-muted text-muted-foreground hover:bg-accent",
                  )}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              );
            })}
          </div>

          <div className="flex-1 overflow-y-auto p-5">
            {tab === "explain" && <AIExplainTab reel={reel} />}
            {tab === "arch" && <ArchTab reel={reel} />}
            {tab === "stack" && <StackTab reel={reel} />}
            {tab === "folders" && <FoldersTab reel={reel} />}
            {tab === "interview" && <InterviewTab reel={reel} />}
            {tab === "quiz" && <QuizTab reel={reel} />}
            {tab === "related" && <RelatedTab reel={reel} />}
            {tab === "ask" && <AskAITab reel={reel} />}
          </div>
        </div>
      )}
    </Drawer>
  );
}

/* ---------------------- Tabs ---------------------- */

function AIExplainTab({ reel }: { reel: Reel }) {
  const paragraphs = [
    `**Problem.** ${reel.problem}`,
    `**Solution.** ${reel.solution}`,
    `**Why this matters.** This project blends ${reel.techStack.slice(0, 3).join(", ")} to solve a real, measurable pain point — the kind of end-to-end thinking recruiters look for.`,
    `**Key learning outcomes.** After building this, you'll understand system design under real constraints, data pipelines, and how to ship a demo people actually use.`,
  ];
  return <StreamedText key={reel.id} paragraphs={paragraphs} />;
}

function StreamedText({ paragraphs }: { paragraphs: string[] }) {
  const [phase, setPhase] = useState<"thinking" | "generating" | "streaming" | "done">("thinking");
  const [visible, setVisible] = useState<string[]>([]);
  const cancelledRef = useRef(false);

  useEffect(() => {
    cancelledRef.current = false;
    setPhase("thinking");
    setVisible([]);
    const t1 = setTimeout(() => setPhase("generating"), 500);
    const t2 = setTimeout(() => setPhase("streaming"), 1100);
    let idx = 0;
    let wordIdx = 0;
    let acc = "";
    let interval: ReturnType<typeof setInterval> | null = null;
    const t3 = setTimeout(() => {
      interval = setInterval(() => {
        if (cancelledRef.current) return;
        if (idx >= paragraphs.length) {
          if (interval) clearInterval(interval);
          setPhase("done");
          return;
        }
        const words = paragraphs[idx].split(" ");
        if (wordIdx >= words.length) {
          setVisible((v) => {
            const next = [...v];
            next[idx] = acc;
            return next;
          });
          idx += 1;
          wordIdx = 0;
          acc = "";
          return;
        }
        acc += (wordIdx === 0 ? "" : " ") + words[wordIdx];
        wordIdx += 1;
        setVisible((v) => {
          const next = [...v];
          next[idx] = acc;
          return next;
        });
      }, 35);
    }, 1200);
    return () => {
      cancelledRef.current = true;
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      if (interval) clearInterval(interval);
    };
  }, [paragraphs]);

  return (
    <div className="space-y-4">
      {phase !== "done" && (
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-primary" />
            <span className="relative inline-flex h-2 w-2 rounded-full gradient-brand" />
          </span>
          {phase === "thinking" && "AI is thinking…"}
          {phase === "generating" && "Generating explanation…"}
          {phase === "streaming" && "Streaming response…"}
        </div>
      )}
      {visible.map((p, i) => (
        <p
          key={i}
          className="animate-fade-in-up text-sm leading-relaxed text-foreground/90"
          dangerouslySetInnerHTML={{
            __html: p.replace(/\*\*(.+?)\*\*/g, '<strong class="text-foreground">$1</strong>'),
          }}
        />
      ))}
    </div>
  );
}

function ArchTab({ reel }: { reel: Reel }) {
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border/70 bg-muted/30 p-4">
        <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          System architecture
        </div>
        <p className="text-sm leading-relaxed">{reel.architecture}</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[
          { title: "Data flow", body: "Bi-directional, event-driven" },
          { title: "Auth", body: "JWT + refresh, RBAC" },
          { title: "Storage", body: "S3 signed URLs for media" },
          { title: "Realtime", body: "WebSocket / MQTT where relevant" },
        ].map((c) => (
          <div key={c.title} className="rounded-xl border border-border/70 bg-card p-3">
            <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
              {c.title}
            </div>
            <div className="mt-1 text-sm font-medium">{c.body}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StackTab({ reel }: { reel: Reel }) {
  return (
    <div className="flex flex-wrap gap-2">
      {reel.techStack.map((t) => (
        <span
          key={t}
          className="rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium"
        >
          {t}
        </span>
      ))}
    </div>
  );
}

function FoldersTab({ reel }: { reel: Reel }) {
  return (
    <pre className="overflow-x-auto rounded-2xl border border-border/70 bg-muted/40 p-4 text-xs leading-relaxed">
      <code>{reel.folderStructure}</code>
    </pre>
  );
}

function InterviewTab({ reel }: { reel: Reel }) {
  return (
    <div className="space-y-3">
      {reel.interviewQuestions.map((q, i) => (
        <details
          key={i}
          className="group rounded-xl border border-border/70 bg-card p-4 open:bg-accent/40"
        >
          <summary className="cursor-pointer list-none text-sm font-semibold">
            <span className="mr-2 text-muted-foreground">Q{i + 1}.</span>
            {q.q}
          </summary>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{q.a}</p>
        </details>
      ))}
    </div>
  );
}

function QuizTab({ reel }: { reel: Reel }) {
  const store = useReelsStore();
  const alreadyAnswered = !!store.quizzesAnswered[reel.id];
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(alreadyAnswered);

  useEffect(() => {
    setSelected(null);
    setSubmitted(!!store.quizzesAnswered[reel.id]);
  }, [reel.id, store.quizzesAnswered]);

  const submit = () => {
    if (selected == null) return;
    setSubmitted(true);
    const correct = selected === reel.quiz.correct;
    if (correct && !alreadyAnswered) {
      const { newlyAwarded, badgeUnlocked } = store.awardQuizXP(reel.id, reel.quiz.xp);
      if (newlyAwarded) {
        toast.success(`+${reel.quiz.xp} XP earned!`, { icon: "⭐" });
        if (badgeUnlocked) {
          setTimeout(
            () => toast.success(`Badge unlocked: ${badgeUnlocked}`, { icon: "🏆" }),
            600,
          );
        }
      }
    } else if (!correct) {
      toast.error("Not quite — read the explanation below");
    } else {
      toast.info("You've already earned XP for this quiz");
    }
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-2.5 py-1 font-medium">
          <Trophy className="h-3 w-3" /> {store.xp} XP
        </span>
        <span>+{reel.quiz.xp} XP per correct</span>
      </div>
      <h4 className="text-base font-semibold">{reel.quiz.question}</h4>
      <div className="mt-4 space-y-2">
        {reel.quiz.options.map((opt, i) => {
          const isSelected = selected === i;
          const isCorrect = submitted && i === reel.quiz.correct;
          const isWrong = submitted && isSelected && i !== reel.quiz.correct;
          return (
            <button
              key={i}
              disabled={submitted}
              onClick={() => setSelected(i)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl border-2 px-4 py-3 text-left text-sm transition-all",
                !submitted && isSelected && "border-primary bg-primary/10",
                !submitted && !isSelected && "border-border bg-card hover:border-primary/50",
                isCorrect && "border-emerald-500 bg-emerald-500/10",
                isWrong && "border-rose-500 bg-rose-500/10",
                submitted && "cursor-default",
              )}
            >
              <span
                className={cn(
                  "grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold",
                  isCorrect && "bg-emerald-500 text-white",
                  isWrong && "bg-rose-500 text-white",
                  !submitted && "bg-muted",
                )}
              >
                {isCorrect ? <Check className="h-3.5 w-3.5" /> : String.fromCharCode(65 + i)}
              </span>
              <span className="flex-1">{opt}</span>
            </button>
          );
        })}
      </div>

      {!submitted ? (
        <button
          onClick={submit}
          disabled={selected == null}
          className="mt-5 w-full rounded-full gradient-brand px-5 py-3 text-sm font-semibold text-white shadow-glow transition-transform disabled:cursor-not-allowed disabled:opacity-40 enabled:hover:scale-[1.02]"
        >
          Submit answer
        </button>
      ) : (
        <div className="mt-5 rounded-xl border border-border bg-muted/40 p-4 text-sm leading-relaxed">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
            Explanation
          </div>
          {reel.quiz.explanation}
        </div>
      )}
    </div>
  );
}

function RelatedTab({ reel }: { reel: Reel }) {
  return (
    <div className="space-y-2">
      {reel.related.length === 0 && (
        <p className="text-sm text-muted-foreground">No related projects yet.</p>
      )}
      {reel.related.map((r) => (
        <div
          key={r}
          className="flex items-center justify-between rounded-xl border border-border bg-card p-3 text-sm"
        >
          <span className="font-medium capitalize">{r.replace(/-/g, " ")}</span>
          <span className="text-xs text-muted-foreground">Coming soon</span>
        </div>
      ))}
    </div>
  );
}

function AskAITab({ reel }: { reel: Reel }) {
  const [messages, setMessages] = useState<{ role: "user" | "ai"; text: string }[]>([
    {
      role: "ai",
      text: `Hi! I'm the AI mentor for "${reel.title}". Ask me anything about the architecture, code, or how to extend it.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);

  const send = () => {
    const q = input.trim();
    if (!q || pending) return;
    setMessages((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setPending(true);
    // Simulated streamed response
    setTimeout(() => {
      const answer = pickAnswer(q, reel);
      setMessages((m) => [...m, { role: "ai", text: answer }]);
      setPending(false);
    }, 900);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 space-y-3">
        {messages.map((m, i) => (
          <div
            key={i}
            className={cn(
              "max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed animate-fade-in-up",
              m.role === "ai"
                ? "bg-muted"
                : "ml-auto gradient-brand text-white shadow-glow",
            )}
          >
            {m.text}
          </div>
        ))}
        {pending && (
          <div className="max-w-[85%] rounded-2xl bg-muted px-4 py-2.5 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              Thinking
              <span className="animate-pulse">·</span>
              <span className="animate-pulse [animation-delay:120ms]">·</span>
              <span className="animate-pulse [animation-delay:240ms]">·</span>
            </span>
          </div>
        )}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="sticky bottom-0 mt-4 flex items-center gap-2 border-t border-border/60 bg-card pt-3"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about this project…"
          className="flex-1 rounded-full border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
        />
        <button
          type="submit"
          disabled={!input.trim() || pending}
          className="grid h-10 w-10 place-items-center rounded-full gradient-brand text-white shadow-glow disabled:opacity-40"
          aria-label="Send"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}

function pickAnswer(q: string, reel: Reel) {
  const lower = q.toLowerCase();
  if (lower.includes("stack") || lower.includes("tech"))
    return `This project uses ${reel.techStack.join(", ")}. Each was chosen for a specific tradeoff — happy to break any of them down.`;
  if (lower.includes("architecture") || lower.includes("design")) return reel.architecture;
  if (lower.includes("problem")) return reel.problem;
  if (lower.includes("start") || lower.includes("build") || lower.includes("how"))
    return `Start by cloning the repo, then set up the ${reel.techStack[0]} side. The folder structure tab shows the layout — I recommend building the ${reel.techStack[1] ?? "backend"} first.`;
  return `Great question. In this project, ${reel.solution.toLowerCase()} Want me to dive into a specific module?`;
}
