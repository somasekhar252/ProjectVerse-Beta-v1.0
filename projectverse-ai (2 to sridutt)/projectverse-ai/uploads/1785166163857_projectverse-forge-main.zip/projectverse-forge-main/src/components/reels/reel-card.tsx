import { useEffect, useRef, useState, useCallback } from "react";
import type { Reel } from "@/lib/reels-data";
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  GraduationCap,
  FolderOpen,
  Volume2,
  VolumeX,
  Play,
  MoreHorizontal,
  UserPlus,
  UserCheck,
  Github,
  Eye,
  Gauge,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatCount } from "@/lib/format";
import { toast } from "sonner";
import { useReelsStore } from "@/lib/reels-store";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

type Props = {
  reel: Reel;
  active: boolean;
  muted: boolean;
  onToggleMute: () => void;
  onOpenLearn: (reel: Reel) => void;
  onOpenComments: (reel: Reel) => void;
  onOpenProject: (reel: Reel) => void;
  onScrollNext: () => void;
};

const SPEEDS = [0.5, 1, 1.5, 2] as const;

export function ReelCard({
  reel,
  active,
  muted,
  onToggleMute,
  onOpenLearn,
  onOpenComments,
  onOpenProject,
  onScrollNext,
}: Props) {
  const store = useReelsStore();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [speed, setSpeed] = useState<(typeof SPEEDS)[number]>(1);
  const [failed, setFailed] = useState(false);
  const [heartBursts, setHeartBursts] = useState<{ id: number; x: number; y: number }[]>([]);
  const [showBigHeart, setShowBigHeart] = useState(false);
  const lastTapRef = useRef(0);
  const burstId = useRef(0);

  const liked = !!store.likes[reel.id];
  const bookmarked = !!store.bookmarks[reel.id];
  const following = !!store.follows[reel.creator.id];

  const likeCount = reel.stats.likes + (liked ? 1 : 0);
  const bookmarkCount = reel.stats.bookmarks + (bookmarked ? 1 : 0);

  // playback control based on active state
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (active && !failed) {
      v.muted = muted;
      v.playbackRate = speed;
      const p = v.play();
      if (p && typeof p.catch === "function") {
        p.catch(() => {
          // autoplay blocked — will show play overlay
          setPlaying(false);
        });
      }
    } else {
      v.pause();
    }
  }, [active, muted, speed, failed]);

  // update progress
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => setProgress(v.currentTime / (v.duration || 1));
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onErr = () => setFailed(true);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("error", onErr);
    return () => {
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("play", onPlay);
      v.removeEventListener("pause", onPause);
      v.removeEventListener("error", onErr);
    };
  }, []);

  const triggerLikeAnim = useCallback(() => {
    setShowBigHeart(true);
    setTimeout(() => setShowBigHeart(false), 900);
  }, []);

  const handleLike = useCallback(() => {
    if (!liked) triggerLikeAnim();
    store.toggleLike(reel.id);
  }, [liked, reel.id, store, triggerLikeAnim]);

  const handleDoubleTap = useCallback(
    (e: React.MouseEvent) => {
      const now = Date.now();
      if (now - lastTapRef.current < 300) {
        // double
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const id = ++burstId.current;
        setHeartBursts((h) => [...h, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
        setTimeout(() => setHeartBursts((h) => h.filter((b) => b.id !== id)), 1000);
        if (!liked) {
          store.toggleLike(reel.id);
          triggerLikeAnim();
        }
      } else {
        // single-tap — toggle playback
        setTimeout(() => {
          if (Date.now() - lastTapRef.current >= 290) {
            const v = videoRef.current;
            if (!v) return;
            if (v.paused) v.play().catch(() => {});
            else v.pause();
          }
        }, 300);
      }
      lastTapRef.current = now;
    },
    [liked, reel.id, store, triggerLikeAnim],
  );

  const handleShare = useCallback(async () => {
    const url = typeof window !== "undefined" ? `${window.location.origin}/reels?r=${reel.id}` : "";
    const data = { title: reel.title, text: reel.tagline, url };
    try {
      if (typeof navigator !== "undefined" && "share" in navigator) {
        await (navigator as unknown as { share: (d: ShareData) => Promise<void> }).share(data);
        return;
      }
    } catch {
      /* fall through */
    }
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Link copied to clipboard");
    } catch {
      toast.error("Couldn't copy link");
    }
  }, [reel]);

  const handleFollow = () => {
    store.toggleFollow(reel.creator.id);
    toast.success(following ? "Unfollowed" : `Following ${reel.creator.name}`);
  };

  return (
    <section
      className="snap-start-always relative flex h-[100dvh] w-full items-center justify-center overflow-hidden bg-black"
      aria-label={`Reel: ${reel.title}`}
    >
      {/* video */}
      <div
        className="relative h-full w-full max-w-[520px] cursor-pointer select-none"
        onClick={handleDoubleTap}
      >
        {!failed ? (
          <video
            ref={videoRef}
            src={reel.videoUrl}
            poster={reel.poster}
            playsInline
            loop
            preload={active ? "auto" : "metadata"}
            className="h-full w-full object-cover"
          />
        ) : (
          <div
            className="flex h-full w-full flex-col items-center justify-center bg-cover bg-center text-center"
            style={{ backgroundImage: `url(${reel.poster})` }}
          >
            <div className="absolute inset-0 bg-black/60" />
            <div className="relative z-10 px-6">
              <p className="text-sm text-white/90">Video failed to load</p>
              <button
                onClick={() => {
                  setFailed(false);
                  setTimeout(() => videoRef.current?.load(), 50);
                }}
                className="mt-3 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/30 hover:bg-white/20"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {/* gradient overlays for legibility */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/70 to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />

        {/* Play indicator */}
        {!playing && !failed && active && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <span className="grid h-20 w-20 place-items-center rounded-full bg-black/50 backdrop-blur">
              <Play className="h-8 w-8 fill-white text-white" />
            </span>
          </div>
        )}

        {/* Big heart on double tap */}
        {showBigHeart && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <Heart className="animate-heart-pop h-32 w-32 fill-rose-500 text-rose-500 drop-shadow-2xl" />
          </div>
        )}

        {/* Floating heart bursts */}
        {heartBursts.map((b) => (
          <Heart
            key={b.id}
            className="animate-float-up pointer-events-none absolute h-8 w-8 fill-rose-500 text-rose-500"
            style={{ left: b.x - 16, top: b.y - 16 }}
          />
        ))}

        {/* Progress bar */}
        <div className="absolute inset-x-0 bottom-0 z-20 h-1 bg-white/15">
          <div
            className="h-full gradient-brand transition-[width]"
            style={{ width: `${progress * 100}%` }}
          />
        </div>

        {/* Top-right: mute + speed + more */}
        <div className="absolute right-3 top-3 z-20 flex flex-col items-end gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleMute();
            }}
            className="grid h-10 w-10 place-items-center rounded-full bg-black/50 text-white backdrop-blur transition-transform active:scale-90"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="grid h-10 w-10 place-items-center rounded-full bg-black/50 text-white backdrop-blur active:scale-90"
                aria-label="Options"
              >
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              <DropdownMenuItem
                onClick={() => {
                  toast.success("We'll show fewer reels like this");
                  store.hideReel(reel.id);
                  onScrollNext();
                }}
              >
                Not interested
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  store.hideReel(reel.id);
                  toast("Reel hidden");
                  onScrollNext();
                }}
              >
                Hide this reel
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Report submitted")}>
                Report
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
                Playback speed
              </div>
              {SPEEDS.map((s) => (
                <DropdownMenuItem
                  key={s}
                  onClick={() => setSpeed(s)}
                  className={cn(speed === s && "font-semibold text-primary")}
                >
                  <Gauge className="mr-2 h-3.5 w-3.5" />
                  {s}x
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Right side action rail */}
        <div className="absolute bottom-24 right-3 z-20 flex flex-col items-center gap-4 md:bottom-8">
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              handleLike();
            }}
            icon={
              <Heart
                className={cn(
                  "h-7 w-7 transition-transform",
                  liked ? "fill-rose-500 text-rose-500 scale-110" : "text-white",
                )}
              />
            }
            label={formatCount(likeCount)}
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              onOpenComments(reel);
            }}
            icon={<MessageCircle className="h-7 w-7 text-white" />}
            label={formatCount(reel.stats.comments)}
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              store.toggleBookmark(reel.id);
              toast.success(bookmarked ? "Removed from saved" : "Saved to your library");
            }}
            icon={
              <Bookmark
                className={cn(
                  "h-7 w-7 transition-transform",
                  bookmarked ? "fill-amber-400 text-amber-400 scale-110" : "text-white",
                )}
              />
            }
            label={formatCount(bookmarkCount)}
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              handleShare();
            }}
            icon={<Share2 className="h-7 w-7 text-white" />}
            label={formatCount(reel.stats.shares)}
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              onOpenLearn(reel);
            }}
            icon={
              <span className="grid h-11 w-11 place-items-center rounded-full gradient-brand shadow-glow">
                <GraduationCap className="h-5 w-5 text-white" />
              </span>
            }
            label="Learn"
            highlight
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              onOpenProject(reel);
            }}
            icon={<FolderOpen className="h-7 w-7 text-white" />}
            label="Project"
          />
          <ActionButton
            onClick={(e) => {
              e.stopPropagation();
              window.open(reel.githubUrl, "_blank", "noopener");
            }}
            icon={<Github className="h-7 w-7 text-white" />}
            label="Code"
          />
        </div>

        {/* Bottom info panel */}
        <div className="absolute inset-x-0 bottom-0 z-10 px-4 pb-6 pr-20 md:pb-8">
          <div className="mb-3 flex items-center gap-2">
            <div
              className="grid h-10 w-10 place-items-center rounded-full text-sm font-bold text-white"
              style={{ backgroundColor: reel.creator.avatarColor }}
            >
              {reel.creator.name
                .split(" ")
                .map((s) => s[0])
                .join("")}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold text-white">
                @{reel.creator.handle}
              </div>
              <div className="truncate text-[11px] text-white/70">
                {reel.creator.college} · {reel.creator.branch} · {reel.creator.year}
              </div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleFollow();
              }}
              className={cn(
                "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-all",
                following
                  ? "bg-white/10 text-white ring-1 ring-white/30"
                  : "bg-white text-neutral-900 hover:scale-105",
              )}
            >
              {following ? (
                <>
                  <UserCheck className="h-3.5 w-3.5" /> Following
                </>
              ) : (
                <>
                  <UserPlus className="h-3.5 w-3.5" /> Follow
                </>
              )}
            </button>
          </div>

          <h2 className="line-clamp-2 text-lg font-bold text-white drop-shadow-md">
            {reel.title}
          </h2>
          <p className="mt-1 line-clamp-2 text-sm text-white/85">{reel.tagline}</p>

          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <span className="rounded-full bg-white/10 px-2 py-1 text-[10px] font-medium text-white ring-1 ring-white/20 backdrop-blur">
              {reel.category}
            </span>
            <span className="rounded-full gradient-brand px-2 py-1 text-[10px] font-semibold text-white">
              {reel.difficulty}
            </span>
            {reel.techStack.slice(0, 3).map((t) => (
              <span
                key={t}
                className="rounded-full bg-black/40 px-2 py-1 text-[10px] font-medium text-white/90 ring-1 ring-white/10"
              >
                {t}
              </span>
            ))}
          </div>

          <div className="mt-3 flex items-center gap-3 text-[11px] text-white/70">
            <span className="flex items-center gap-1">
              <Eye className="h-3 w-3" /> {formatCount(reel.stats.views)} views
            </span>
            <span>·</span>
            <span>{reel.duration}s</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function ActionButton({
  onClick,
  icon,
  label,
  highlight,
}: {
  onClick: (e: React.MouseEvent) => void;
  icon: React.ReactNode;
  label: string;
  highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="group flex flex-col items-center gap-1 active:scale-90"
      aria-label={label}
    >
      <span
        className={cn(
          "grid h-11 w-11 place-items-center rounded-full transition-transform group-hover:scale-110",
          !highlight && "bg-black/40 backdrop-blur",
        )}
      >
        {icon}
      </span>
      <span className="text-[11px] font-semibold text-white drop-shadow">{label}</span>
    </button>
  );
}
