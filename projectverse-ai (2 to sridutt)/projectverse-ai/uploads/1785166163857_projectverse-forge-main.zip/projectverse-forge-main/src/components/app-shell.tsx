import { Link, useLocation } from "@tanstack/react-router";
import { Compass, Home, Film, PlusSquare, User, Moon, Sun, Sparkles, Wand2 } from "lucide-react";
import type { ReactNode } from "react";
import { useTheme } from "./theme-provider";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/discover", label: "Discover", icon: Compass },
  { to: "/reels", label: "Reels", icon: Film },
  { to: "/generate", label: "Generate", icon: Wand2 },
  { to: "/upload", label: "Upload", icon: PlusSquare },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { pathname } = useLocation();
  const { theme, toggle } = useTheme();
  const isReels = pathname.startsWith("/reels");

  return (
    <div className="min-h-screen w-full bg-background text-foreground">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-border bg-card/40 backdrop-blur-xl md:flex",
        )}
      >
        <Link to="/" className="flex items-center gap-2 px-6 py-6">
          <span className="grid h-9 w-9 place-items-center rounded-xl gradient-brand text-white shadow-glow">
            <Sparkles className="h-5 w-5" />
          </span>
          <div className="leading-tight">
            <div className="text-base font-bold tracking-tight">ProjectVerse</div>
            <div className="text-[10px] font-medium uppercase tracking-widest text-muted-foreground">
              AI · for engineers
            </div>
          </div>
        </Link>

        <nav className="mt-2 flex-1 px-3">
          {NAV.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "group my-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                  active
                    ? "bg-accent text-foreground"
                    : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                )}
              >
                <span
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-lg transition-transform group-hover:scale-105",
                    active ? "gradient-brand text-white shadow-glow" : "bg-muted",
                  )}
                >
                  <Icon className="h-4 w-4" />
                </span>
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-border p-3">
          <button
            onClick={toggle}
            className="flex w-full items-center justify-between rounded-xl bg-muted/50 px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted"
            aria-label="Toggle theme"
          >
            <span className="flex items-center gap-2">
              {theme === "dark" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              {theme === "dark" ? "Dark" : "Light"} mode
            </span>
            <span className="text-xs text-muted-foreground">⇄</span>
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/60 bg-background/70 px-4 py-3 backdrop-blur-xl md:hidden">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-lg gradient-brand text-white">
            <Sparkles className="h-4 w-4" />
          </span>
          <span className="text-sm font-bold tracking-tight">ProjectVerse</span>
        </Link>
        <button
          onClick={toggle}
          className="grid h-9 w-9 place-items-center rounded-full bg-muted"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
        </button>
      </header>

      <main
        className={cn(
          "min-h-[calc(100vh-56px)] md:min-h-screen md:ml-64",
          !isReels && "pb-24 md:pb-0",
        )}
      >
        {children}
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border/70 bg-background/85 backdrop-blur-xl md:hidden">
        <div className="mx-auto grid max-w-md grid-cols-6">
          {NAV.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className="flex flex-col items-center gap-1 px-2 py-2.5 text-[10px] font-medium"
                aria-label={item.label}
              >
                <span
                  className={cn(
                    "grid h-9 w-9 place-items-center rounded-xl transition-all",
                    active ? "gradient-brand text-white shadow-glow" : "text-muted-foreground",
                  )}
                >
                  <Icon className="h-[18px] w-[18px]" />
                </span>
                <span className={active ? "text-foreground" : "text-muted-foreground"}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
