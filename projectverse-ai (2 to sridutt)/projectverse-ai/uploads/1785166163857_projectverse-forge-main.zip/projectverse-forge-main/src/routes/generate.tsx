import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Sparkles, Wand2, Loader2, Copy, Check } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/generate")({
  head: () => ({
    meta: [
      { title: "AI Project Generator — ProjectVerse AI" },
      { name: "description", content: "Turn any idea into a full engineering project blueprint — problem, modules, architecture, roadmap." },
      { property: "og:title", content: "AI Project Generator — ProjectVerse AI" },
      { property: "og:description", content: "From idea to blueprint in seconds, powered by AI." },
    ],
  }),
  component: Generate,
});

type Blueprint = {
  title: string;
  tagline: string;
  problem: string;
  solution: string;
  modules: string[];
  stack: string[];
  architecture: string;
  roadmap: { phase: string; goal: string }[];
};

const PROMPTS = [
  "Smart water quality monitor for rural villages",
  "AI-powered lost & found for college campuses",
  "Personalized study plan generator from syllabus PDF",
  "Real-time carpool matcher for engineering colleges",
];

function synthesize(idea: string): Blueprint {
  const clean = idea.trim() || "your idea";
  const title = clean.length > 60 ? clean.slice(0, 57) + "…" : clean;
  return {
    title,
    tagline: `An AI-native, mobile-first system to ship ${clean.toLowerCase()} for real users.`,
    problem: `Today, solving "${clean}" is manual, slow, and fragmented. Users lack a single tool that combines real-time data, intelligent recommendations, and a friendly mobile experience — leading to wasted time, poor decisions, and low adoption.`,
    solution: `A cross-platform product that captures relevant signals, applies ML for insight, and surfaces personalized actions in under two taps. Offline-first sync, human-in-the-loop review, and a clean data model keep the experience fast and trustworthy.`,
    modules: [
      "Authentication & profiles",
      "Data ingestion pipeline",
      "AI/ML inference service",
      "Notification & alerts engine",
      "Analytics dashboard",
      "Admin & moderation console",
    ],
    stack: ["React Native", "TypeScript", "Node.js", "PostgreSQL", "Redis", "Python (FastAPI)", "TensorFlow"],
    architecture:
      "Mobile client (React Native) → API gateway (Node/Express) → domain services → Postgres for canonical state, Redis for hot cache, Python FastAPI for ML inference. Async jobs on a queue; observability via OpenTelemetry.",
    roadmap: [
      { phase: "Week 1-2", goal: "Domain research, user interviews, wireframes, DB schema" },
      { phase: "Week 3-4", goal: "Auth, core CRUD, baseline mobile UI" },
      { phase: "Week 5-6", goal: "ML inference service + integration, notifications" },
      { phase: "Week 7-8", goal: "Analytics dashboard, beta test with 20 users" },
      { phase: "Week 9-10", goal: "Polish, submit to app stores, publish reel on ProjectVerse" },
    ],
  };
}

function Generate() {
  const [idea, setIdea] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Blueprint | null>(null);
  const [streamedTagline, setStreamedTagline] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!idea.trim()) {
      toast.error("Describe your project idea first");
      return;
    }
    setLoading(true);
    setResult(null);
    setStreamedTagline("");

    // Simulated streaming to feel AI-native
    await new Promise((r) => setTimeout(r, 500));
    const blueprint = synthesize(idea);
    const tagline = blueprint.tagline;
    for (let i = 0; i < tagline.length; i++) {
      setStreamedTagline(tagline.slice(0, i + 1));
      await new Promise((r) => setTimeout(r, 12));
    }
    await new Promise((r) => setTimeout(r, 200));
    setResult(blueprint);
    setLoading(false);
    toast.success("Blueprint ready");
  };

  const copyAll = async () => {
    if (!result) return;
    const text = `# ${result.title}\n\n${result.tagline}\n\n## Problem\n${result.problem}\n\n## Solution\n${result.solution}\n\n## Modules\n${result.modules.map((m) => "- " + m).join("\n")}\n\n## Stack\n${result.stack.join(", ")}\n\n## Architecture\n${result.architecture}\n\n## Roadmap\n${result.roadmap.map((r) => `- **${r.phase}** — ${r.goal}`).join("\n")}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Blueprint copied");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Couldn't copy");
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 md:px-8 md:py-14">
      <div className="text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium">
          <Sparkles className="h-3 w-3 text-primary" />
          AI Project Generator
        </span>
        <h1 className="mt-4 text-3xl font-bold tracking-tight md:text-5xl">
          Turn any idea into a <span className="text-gradient-brand">shippable blueprint</span>
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-sm text-muted-foreground md:text-base">
          Describe your engineering project idea. Get problem framing, modules, stack, architecture,
          and a week-by-week roadmap — instantly.
        </p>
      </div>

      <div className="mt-8 rounded-3xl border border-border bg-card p-4 shadow-glow md:p-6">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g. Smart bus tracking app for my college with real-time ETA…"
          rows={3}
          className="w-full resize-none rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          {PROMPTS.map((p) => (
            <button
              key={p}
              onClick={() => setIdea(p)}
              className="rounded-full border border-border bg-background/60 px-3 py-1 text-xs text-muted-foreground hover:bg-accent"
            >
              {p}
            </button>
          ))}
        </div>
        <div className="mt-4 flex justify-end">
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="inline-flex items-center gap-2 rounded-full gradient-brand px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition-transform hover:scale-105 disabled:opacity-60"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            {loading ? "Generating…" : "Generate blueprint"}
          </button>
        </div>
      </div>

      {(streamedTagline || result) && (
        <div className="mt-8 space-y-5">
          <div className="rounded-3xl border border-border bg-card p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Blueprint</div>
                <h2 className="mt-1 text-2xl font-bold">{result?.title ?? idea}</h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  {streamedTagline}
                  {loading && <span className="ml-0.5 inline-block h-4 w-1.5 animate-pulse bg-primary align-middle" />}
                </p>
              </div>
              {result && (
                <button
                  onClick={copyAll}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-accent"
                >
                  {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? "Copied" : "Copy all"}
                </button>
              )}
            </div>
          </div>

          {result && (
            <div className="grid gap-5 md:grid-cols-2">
              <Section title="Problem">{result.problem}</Section>
              <Section title="Solution">{result.solution}</Section>
              <Section title="Modules">
                <ul className="space-y-1.5 text-sm text-muted-foreground">
                  {result.modules.map((m) => (
                    <li key={m} className="flex items-start gap-2">
                      <span className="mt-1 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                      {m}
                    </li>
                  ))}
                </ul>
              </Section>
              <Section title="Recommended stack">
                <div className="flex flex-wrap gap-1.5">
                  {result.stack.map((s) => (
                    <span key={s} className="rounded-full border border-border bg-background px-2.5 py-1 text-xs font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </Section>
              <div className="md:col-span-2">
                <Section title="Architecture">{result.architecture}</Section>
              </div>
              <div className="md:col-span-2">
                <Section title="10-week roadmap">
                  <ol className="space-y-2">
                    {result.roadmap.map((r) => (
                      <li key={r.phase} className="flex items-start gap-3 rounded-xl border border-border/60 bg-background p-3">
                        <span className="rounded-full gradient-brand px-2.5 py-1 text-[10px] font-bold text-white">
                          {r.phase}
                        </span>
                        <span className="text-sm text-muted-foreground">{r.goal}</span>
                      </li>
                    ))}
                  </ol>
                </Section>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">{title}</h3>
      <div className="mt-3 text-sm leading-relaxed text-muted-foreground">{children}</div>
    </div>
  );
}
