import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo } from "react";
import { useReelsStore } from "@/lib/reels-store";
import { REELS } from "@/lib/reels-data";
import { Trophy, Award, Heart, Bookmark, Film, UserCheck, LogOut, LogIn } from "lucide-react";
import { formatCount } from "@/lib/format";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Your profile — ProjectVerse AI" },
      { name: "description", content: "Your XP, badges, saved projects, and activity." },
    ],
  }),
  component: Profile,
});

function Profile() {
  const store = useReelsStore();
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const liked = useMemo(
    () => REELS.filter((r) => store.likes[r.id]),
    [store.likes],
  );
  const saved = useMemo(
    () => REELS.filter((r) => store.bookmarks[r.id]),
    [store.bookmarks],
  );
  const followingCount = Object.values(store.follows).filter(Boolean).length;

  const levelProgress = Math.min(100, (store.xp % 100));

  async function handleSignOut() {
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate({ to: "/" });
  }

  const displayName = (user?.user_metadata as { display_name?: string; full_name?: string } | undefined)?.display_name
    ?? (user?.user_metadata as { full_name?: string } | undefined)?.full_name
    ?? user?.email?.split("@")[0]
    ?? "Guest";
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:px-8 md:py-12">
      {/* Header card */}
      <section className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 md:p-10">
        <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center">
          <div className="grid h-24 w-24 place-items-center rounded-2xl gradient-brand text-2xl font-bold text-white shadow-glow">
            {initials}
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
              {user ? displayName : "Your ProjectVerse"}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {loading
                ? "Loading…"
                : user
                  ? user.email
                  : "Guest learner · Sign in to save progress across devices"}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {store.badges.length === 0 && (
                <span className="rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                  Answer a quiz in a reel to earn your first badge
                </span>
              )}
              {store.badges.map((b) => (
                <span
                  key={b}
                  className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-500"
                >
                  <Award className="h-3 w-3" /> {b}
                </span>
              ))}
            </div>
            <div className="mt-5">
              {user ? (
                <button
                  onClick={handleSignOut}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground"
                >
                  <LogOut className="h-3.5 w-3.5" /> Sign out
                </button>
              ) : (
                <Link
                  to="/auth"
                  className="inline-flex items-center gap-1.5 rounded-full gradient-brand px-4 py-2 text-xs font-semibold text-white shadow-glow"
                >
                  <LogIn className="h-3.5 w-3.5" /> Sign in to sync progress
                </Link>
              )}
            </div>
          </div>

          <div className="w-full max-w-xs rounded-2xl border border-border bg-background/40 p-4 backdrop-blur">
            <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Trophy className="h-3.5 w-3.5 text-amber-500" /> Level {Math.floor(store.xp / 100) + 1}
              </span>
              <span>{store.xp} XP</span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full gradient-brand transition-[width]"
                style={{ width: `${levelProgress}%` }}
              />
            </div>
            <div className="mt-1.5 text-[10px] text-muted-foreground">
              {100 - levelProgress} XP to next level
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat icon={<Heart className="h-4 w-4" />} label="Liked" value={liked.length} />
        <Stat icon={<Bookmark className="h-4 w-4" />} label="Saved" value={saved.length} />
        <Stat icon={<UserCheck className="h-4 w-4" />} label="Following" value={followingCount} />
        <Stat icon={<Film className="h-4 w-4" />} label="Reels watched" value={Object.keys(store.quizzesAnswered).length} />
      </section>

      {/* Saved */}
      <Section title="Saved for later" empty="Bookmark a reel — it'll appear here.">
        <Grid items={saved} />
      </Section>

      {/* Liked */}
      <Section title="Liked reels" empty="Double-tap a reel to like it — it'll appear here.">
        <Grid items={liked} />
      </Section>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        {icon} {label}
      </div>
      <div className="mt-1 text-2xl font-bold">{value}</div>
    </div>
  );
}

function Section({
  title,
  empty,
  children,
}: {
  title: string;
  empty: string;
  children: React.ReactNode;
}) {
  const hasContent = Array.isArray((children as { props?: { items?: unknown[] } }).props?.items)
    ? ((children as { props: { items: unknown[] } }).props.items.length ?? 0) > 0
    : true;
  return (
    <section className="mt-10">
      <h2 className="mb-4 text-lg font-semibold tracking-tight">{title}</h2>
      {hasContent ? (
        children
      ) : (
        <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          {empty}
        </div>
      )}
    </section>
  );
}

function Grid({ items }: { items: typeof REELS }) {
  if (items.length === 0) return null;
  return (
    <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
      {items.map((r) => (
        <Link
          key={r.id}
          to="/reels"
          className="group relative aspect-[9/13] overflow-hidden rounded-2xl border border-border"
        >
          <img
            src={r.poster}
            alt={r.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
          <div className="absolute inset-x-3 bottom-3 text-white">
            <div className="text-[10px] font-semibold uppercase tracking-widest opacity-80">
              {r.category}
            </div>
            <div className="mt-1 line-clamp-2 text-sm font-semibold">{r.title}</div>
            <div className="mt-1 text-[10px] opacity-80">❤ {formatCount(r.stats.likes)}</div>
          </div>
        </Link>
      ))}
    </div>
  );
}
