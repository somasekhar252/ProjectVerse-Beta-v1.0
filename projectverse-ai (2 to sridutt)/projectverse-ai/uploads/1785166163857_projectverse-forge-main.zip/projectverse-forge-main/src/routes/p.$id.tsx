import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getReel, REELS, type Reel } from "@/lib/reels-data";
import { formatCount } from "@/lib/format";
import { ArrowLeft, Github, Heart, Bookmark, Eye, ExternalLink, Sparkles, Code2, Layers, BookOpen, MessageSquareQuote, GraduationCap } from "lucide-react";
import { useReelsStore } from "@/lib/reels-store";
import { toast } from "sonner";

export const Route = createFileRoute("/p/$id")({
  loader: ({ params }) => {
    const reel = getReel(params.id);
    if (!reel) throw notFound();
    return { reel };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Project not found — ProjectVerse AI" }, { name: "robots", content: "noindex" }] };
    }
    const { reel } = loaderData;
    return {
      meta: [
        { title: `${reel.title} — ProjectVerse AI` },
        { name: "description", content: reel.tagline },
        { property: "og:title", content: reel.title },
        { property: "og:description", content: reel.tagline },
        { property: "og:image", content: reel.poster },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ProjectPage,
  notFoundComponent: () => (
    <div className="mx-auto max-w-2xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold">Project not found</h1>
      <p className="mt-2 text-sm text-muted-foreground">This project doesn't exist or was removed.</p>
      <Link to="/discover" className="mt-6 inline-flex rounded-full gradient-brand px-5 py-2.5 text-sm font-semibold text-white">
        Back to Discover
      </Link>
    </div>
  ),
  errorComponent: () => (
    <div className="mx-auto max-w-2xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold">Something went wrong</h1>
      <Link to="/" className="mt-6 inline-flex rounded-full gradient-brand px-5 py-2.5 text-sm font-semibold text-white">Go home</Link>
    </div>
  ),
});

function ProjectPage() {
  const { reel } = Route.useLoaderData() as { reel: Reel };
  const store = useReelsStore();
  const liked = !!store.likes[reel.id];
  const bookmarked = !!store.bookmarks[reel.id];
  const related = reel.related
    .map((id: string) => REELS.find((r) => r.id === id))
    .filter((r): r is Reel => Boolean(r));

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 md:px-8 md:py-10">
      <Link to="/reels" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to reels
      </Link>

      {/* Hero */}
      <section className="mt-4 grid gap-6 md:grid-cols-[1.1fr_1fr]">
        <div className="relative aspect-video overflow-hidden rounded-3xl border border-border">
          <img src={reel.poster} alt={reel.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent" />
          <span className="absolute left-4 top-4 rounded-full gradient-brand px-3 py-1 text-xs font-semibold text-white shadow-glow">
            {reel.difficulty}
          </span>
        </div>

        <div>
          <div className="text-xs font-medium uppercase tracking-widest text-muted-foreground">{reel.category}</div>
          <h1 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">{reel.title}</h1>
          <p className="mt-2 text-base text-muted-foreground">{reel.tagline}</p>

          <div className="mt-4 flex flex-wrap gap-1.5">
            {reel.techStack.map((t: string) => (
              <span key={t} className="rounded-full border border-border bg-card px-2.5 py-1 text-xs font-medium">
                {t}
              </span>
            ))}
          </div>

          <div className="mt-5 flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-full text-sm font-bold text-white" style={{ backgroundColor: reel.creator.avatarColor }}>
              {reel.creator.name.split(" ").map((s: string) => s[0]).join("")}
            </div>
            <div className="text-sm">
              <div className="font-semibold">{reel.creator.name}</div>
              <div className="text-xs text-muted-foreground">{reel.creator.college} · {reel.creator.branch} · {reel.creator.year}</div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <button
              onClick={() => {
                store.toggleLike(reel.id);
                toast.success(liked ? "Unliked" : "Liked");
              }}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold hover:bg-accent"
            >
              <Heart className={liked ? "h-4 w-4 fill-rose-500 text-rose-500" : "h-4 w-4"} />
              {formatCount(reel.stats.likes + (liked ? 1 : 0))}
            </button>
            <button
              onClick={() => {
                store.toggleBookmark(reel.id);
                toast.success(bookmarked ? "Removed" : "Saved");
              }}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold hover:bg-accent"
            >
              <Bookmark className={bookmarked ? "h-4 w-4 fill-amber-400 text-amber-400" : "h-4 w-4"} />
              Save
            </button>
            <a
              href={reel.githubUrl}
              target="_blank"
              rel="noopener"
              className="inline-flex items-center gap-2 rounded-full gradient-brand px-4 py-2 text-sm font-semibold text-white shadow-glow"
            >
              <Github className="h-4 w-4" /> View code <ExternalLink className="h-3 w-3" />
            </a>
          </div>

          <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Eye className="h-3 w-3" /> {formatCount(reel.stats.views)} views</span>
            <span>{formatCount(reel.stats.comments)} comments</span>
            <span>{reel.duration}s</span>
          </div>
        </div>
      </section>

      {/* Sections */}
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <Card icon={<Sparkles className="h-4 w-4" />} title="Problem">
          <p className="text-sm leading-relaxed text-muted-foreground">{reel.problem}</p>
        </Card>
        <Card icon={<Sparkles className="h-4 w-4" />} title="Solution">
          <p className="text-sm leading-relaxed text-muted-foreground">{reel.solution}</p>
        </Card>
        <Card icon={<Layers className="h-4 w-4" />} title="Architecture">
          <p className="text-sm leading-relaxed text-muted-foreground">{reel.architecture}</p>
        </Card>
        <Card icon={<Code2 className="h-4 w-4" />} title="Folder structure">
          <pre className="overflow-x-auto rounded-xl bg-muted p-3 text-[11px] leading-relaxed">
            {reel.folderStructure}
          </pre>
        </Card>
      </div>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <MessageSquareQuote className="h-4 w-4 text-primary" /> Interview questions
        </h2>
        <div className="mt-4 space-y-4">
          {reel.interviewQuestions.map((qa: { q: string; a: string }, i: number) => (
            <div key={i} className="rounded-xl border border-border/60 bg-background/60 p-4">
              <div className="text-sm font-semibold">Q{i + 1}. {qa.q}</div>
              <div className="mt-1 text-sm text-muted-foreground">{qa.a}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-border bg-card p-6">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <GraduationCap className="h-4 w-4 text-primary" /> Quick quiz
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">{reel.quiz.question}</p>
        <div className="mt-3 grid gap-2">
          {reel.quiz.options.map((opt: string, i: number) => (
            <button
              key={i}
              onClick={() => {
                if (i === reel.quiz.correct) {
                  const res = store.awardQuizXP(reel.id, reel.quiz.xp);
                  if (res.newlyAwarded) toast.success(`Correct! +${reel.quiz.xp} XP`);
                  else toast.success("Correct!");
                  if (res.badgeUnlocked) toast.success(`Badge unlocked: ${res.badgeUnlocked} 🏆`);
                } else {
                  toast.error(`Not quite. ${reel.quiz.explanation}`);
                }
              }}
              className="rounded-xl border border-border bg-background px-4 py-3 text-left text-sm transition-colors hover:bg-accent"
            >
              {opt}
            </button>
          ))}
        </div>
      </section>

      {related.length > 0 && (
        <section className="mt-10">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <BookOpen className="h-4 w-4 text-primary" /> Related projects
          </h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {related.map((r: Reel) => (
              <Link
                key={r.id}
                to="/p/$id"
                params={{ id: r.id }}
                className="group relative aspect-[16/10] overflow-hidden rounded-2xl border border-border"
              >
                <img src={r.poster} alt={r.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute inset-x-3 bottom-3 text-white">
                  <div className="text-sm font-semibold">{r.title}</div>
                  <div className="line-clamp-1 text-[11px] text-white/80">{r.tagline}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Card({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h3 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
        {icon} {title}
      </h3>
      <div className="mt-3">{children}</div>
    </div>
  );
}
