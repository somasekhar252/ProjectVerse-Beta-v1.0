import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { REELS, type Reel } from "@/lib/reels-data";
import { ReelCard } from "@/components/reels/reel-card";
import { LearnDrawer } from "@/components/reels/learn-drawer";
import { CommentsDrawer } from "@/components/reels/comments-drawer";
import { useReelsStore } from "@/lib/reels-store";
import { toast } from "sonner";

export const Route = createFileRoute("/reels")({
  head: () => ({
    meta: [
      { title: "Reels — ProjectVerse AI" },
      {
        name: "description",
        content:
          "Swipe through short engineering project demos — problem, solution, tech, and code — with an AI mentor.",
      },
      { property: "og:title", content: "Engineering Reels — ProjectVerse AI" },
      {
        property: "og:description",
        content: "Vertical, AI-native reels for real engineering projects.",
      },
    ],
  }),
  component: ReelsPage,
});

function ReelsPage() {
  const store = useReelsStore();
  const navigate = useNavigate();
  const scrollerRef = useRef<HTMLDivElement>(null);
  const sectionsRef = useRef<HTMLElement[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [learnReel, setLearnReel] = useState<Reel | null>(null);
  const [commentsReel, setCommentsReel] = useState<Reel | null>(null);

  const feed = useMemo(() => REELS.filter((r) => !store.hidden[r.id]), [store.hidden]);

  // Restore last watched
  const restoredRef = useRef(false);
  useEffect(() => {
    if (restoredRef.current) return;
    if (feed.length === 0) return;
    const idx = Math.min(store.lastReelIndex, feed.length - 1);
    if (idx > 0 && scrollerRef.current) {
      const el = sectionsRef.current[idx];
      if (el) {
        scrollerRef.current.scrollTo({ top: el.offsetTop, behavior: "auto" });
        setActiveIndex(idx);
        toast("Resumed where you left off", { duration: 1800 });
      }
    }
    restoredRef.current = true;
  }, [feed, store.lastReelIndex]);

  // IntersectionObserver-driven active reel detection
  useEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller) return;
    const observer = new IntersectionObserver(
      (entries) => {
        // Pick the most-visible entry
        let bestIdx = -1;
        let bestRatio = 0;
        for (const entry of entries) {
          const idx = sectionsRef.current.findIndex((el) => el === entry.target);
          if (idx === -1) continue;
          if (entry.intersectionRatio > bestRatio) {
            bestRatio = entry.intersectionRatio;
            bestIdx = idx;
          }
        }
        if (bestIdx !== -1 && bestRatio >= 0.7) {
          setActiveIndex((prev) => (prev === bestIdx ? prev : bestIdx));
        }
      },
      { root: scroller, threshold: [0, 0.5, 0.7, 0.9, 1] },
    );
    sectionsRef.current.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, [feed.length]);

  useEffect(() => {
    store.setLastIndex(activeIndex);
  }, [activeIndex, store]);

  // Keyboard navigation
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "PageDown" || e.key === "j") {
        e.preventDefault();
        scrollToIndex(Math.min(activeIndex + 1, feed.length - 1));
      } else if (e.key === "ArrowUp" || e.key === "PageUp" || e.key === "k") {
        e.preventDefault();
        scrollToIndex(Math.max(activeIndex - 1, 0));
      } else if (e.key === "m") {
        store.setMuted(!store.muted);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeIndex, feed.length, store.muted]);

  const scrollToIndex = useCallback((i: number) => {
    const el = sectionsRef.current[i];
    if (el && scrollerRef.current) {
      scrollerRef.current.scrollTo({ top: el.offsetTop, behavior: "smooth" });
    }
  }, []);

  const scrollNext = useCallback(() => {
    scrollToIndex(Math.min(activeIndex + 1, feed.length - 1));
  }, [activeIndex, feed.length, scrollToIndex]);

  if (feed.length === 0) {
    return (
      <div className="grid h-[100dvh] place-items-center bg-background p-6 text-center">
        <div>
          <h2 className="text-xl font-semibold">No reels to show</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            You've hidden everything. Reset from your profile to see reels again.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative -m-0 md:-mr-0 md:h-[100dvh] md:overflow-hidden">
      <div
        ref={scrollerRef}
        className="snap-y-mandatory scrollbar-hide h-[100dvh] w-full overflow-y-scroll bg-black"
      >
        {feed.map((reel, i) => (
          <div
            key={reel.id}
            ref={(el) => {
              if (el) sectionsRef.current[i] = el;
            }}
          >
            <ReelCard
              reel={reel}
              active={i === activeIndex}
              muted={store.muted}
              onToggleMute={() => store.setMuted(!store.muted)}
              onOpenLearn={setLearnReel}
              onOpenComments={setCommentsReel}
              onOpenProject={(r) => navigate({ to: "/p/$id", params: { id: r.id } })}
              onScrollNext={scrollNext}
            />
          </div>
        ))}
      </div>

      {/* Progress dots (desktop only) */}
      <div className="pointer-events-none absolute right-4 top-1/2 z-30 hidden -translate-y-1/2 flex-col gap-1.5 md:flex">
        {feed.map((_, i) => (
          <span
            key={i}
            className={`h-1.5 w-1.5 rounded-full transition-all ${
              i === activeIndex ? "gradient-brand h-6" : "bg-white/30"
            }`}
          />
        ))}
      </div>

      <LearnDrawer
        reel={learnReel}
        open={!!learnReel}
        onClose={() => setLearnReel(null)}
      />
      <CommentsDrawer
        reel={commentsReel}
        open={!!commentsReel}
        onClose={() => setCommentsReel(null)}
      />
    </div>
  );
}
