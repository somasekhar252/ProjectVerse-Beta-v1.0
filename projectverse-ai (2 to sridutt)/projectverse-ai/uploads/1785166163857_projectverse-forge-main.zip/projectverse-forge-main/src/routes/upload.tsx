import { createFileRoute, Link } from "@tanstack/react-router";
import { Wrench, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/upload")({
  head: () => ({
    meta: [
      { title: "Upload project — ProjectVerse AI" },
      { name: "description", content: "Share your engineering project with the world." },
    ],
  }),
  component: Upload,
});

function Upload() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 text-center md:py-24">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl gradient-brand text-white shadow-glow">
        <Wrench className="h-7 w-7" />
      </div>
      <h1 className="mt-6 text-3xl font-bold tracking-tight md:text-4xl">Project upload</h1>
      <p className="mt-3 text-base text-muted-foreground">
        The full upload flow — with AI-assisted generation of every project section, owner-only
        edit rights, and privacy controls — ships next phase alongside auth.
      </p>
      <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-500">
        Coming next · Phase 2
      </div>
      <div className="mt-8">
        <Link
          to="/reels"
          className="inline-flex items-center gap-2 rounded-full gradient-brand px-5 py-3 text-sm font-semibold text-white shadow-glow"
        >
          Explore reels while you wait <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
