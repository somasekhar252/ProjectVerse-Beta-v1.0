import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Compass, Film, Rocket, Users, Zap } from "lucide-react";
import { REELS } from "@/lib/reels-data";
import { formatCount } from "@/lib/format";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const trending = REELS.slice(0, 3);
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-14">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 md:p-14">
        <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-fuchsia-500/20 blur-3xl" />
        <div className="relative">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-3 py-1 text-xs font-medium backdrop-blur">
            <Sparkles className="h-3 w-3 text-primary" />
            AI-native · built for engineering students
          </span>
          <h1 className="mt-5 max-w-3xl text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl">
            Where engineering students <span className="text-gradient-brand">build, learn</span> &amp; ship real projects.
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
            Discover real engineering projects from students worldwide. Swipe through reels,
            learn architectures, take quizzes, and get an AI mentor — from your first year to
            your first job.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/reels"
              className="inline-flex items-center gap-2 rounded-full gradient-brand px-5 py-3 text-sm font-semibold text-white shadow-glow transition-transform hover:scale-105"
            >
              <Film className="h-4 w-4" /> Watch Engineering Reels
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/discover"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-5 py-3 text-sm font-semibold backdrop-blur hover:bg-accent"
            >
              <Compass className="h-4 w-4" /> Discover projects
            </Link>
          </div>

          <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              ["12K+", "Projects"],
              ["48K+", "Students"],
              ["1.2M+", "Learners"],
              ["380+", "Colleges"],
            ].map(([v, l]) => (
              <div key={l} className="rounded-2xl border border-border/60 bg-background/40 p-4 backdrop-blur">
                <div className="text-2xl font-bold tracking-tight">{v}</div>
                <div className="text-xs text-muted-foreground">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mt-12 grid gap-4 md:grid-cols-3">
        {[
          {
            icon: Rocket,
            title: "AI Project Generator",
            body: "Turn any idea into a full project blueprint — problem, modules, architecture, roadmap.",
          },
          {
            icon: Zap,
            title: "Engineering Reels",
            body: "30–90s vertical demos of real student projects. Problem → solution → code.",
          },
          {
            icon: Users,
            title: "Learn with community",
            body: "Follow builders from your college, fork projects, ask their AI mentor, ship together.",
          },
        ].map((f) => {
          const Icon = f.icon;
          return (
            <div
              key={f.title}
              className="rounded-2xl border border-border bg-card p-6 transition-transform hover:-translate-y-1"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl gradient-brand text-white shadow-glow">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
            </div>
          );
        })}
      </section>

      {/* Trending */}
      <section className="mt-14">
        <div className="mb-5 flex items-end justify-between">
          <div>
            <h2 className="text-xl font-semibold tracking-tight md:text-2xl">Trending reels</h2>
            <p className="text-sm text-muted-foreground">Real engineering projects, ranked by learners.</p>
          </div>
          <Link
            to="/reels"
            className="text-sm font-semibold text-primary hover:underline"
          >
            See all →
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {trending.map((r) => (
            <Link
              key={r.id}
              to="/reels"
              className="group relative aspect-[9/14] overflow-hidden rounded-2xl border border-border"
            >
              <img
                src={r.poster}
                alt={r.title}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
              <div className="absolute inset-x-4 bottom-4 text-white">
                <span className="rounded-full gradient-brand px-2 py-1 text-[10px] font-semibold">
                  {r.difficulty}
                </span>
                <h3 className="mt-2 text-base font-semibold leading-tight">{r.title}</h3>
                <p className="mt-1 line-clamp-1 text-xs text-white/80">{r.tagline}</p>
                <div className="mt-2 flex items-center gap-3 text-[11px] text-white/70">
                  <span>❤ {formatCount(r.stats.likes)}</span>
                  <span>👁 {formatCount(r.stats.views)}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
