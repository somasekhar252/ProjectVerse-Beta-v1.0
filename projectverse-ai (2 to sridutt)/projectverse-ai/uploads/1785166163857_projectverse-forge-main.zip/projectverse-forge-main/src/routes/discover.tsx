import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { REELS } from "@/lib/reels-data";
import { formatCount } from "@/lib/format";
import { Search, SlidersHorizontal, Heart, Bookmark, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/discover")({
  head: () => ({
    meta: [
      { title: "Discover projects — ProjectVerse AI" },
      {
        name: "description",
        content: "Search and filter thousands of engineering projects by tech, category, and difficulty.",
      },
    ],
  }),
  component: Discover,
});

const CATEGORIES = ["All", "AI · Mobile", "AI · SaaS", "IoT · Full Stack", "IoT · Data", "IoT · Safety", "EdTech · Full Stack"];
const DIFFICULTIES = ["All", "Beginner", "Intermediate", "Advanced"] as const;

function Discover() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("All");
  const [diff, setDiff] = useState<(typeof DIFFICULTIES)[number]>("All");

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return REELS.filter((r) => {
      if (cat !== "All" && r.category !== cat) return false;
      if (diff !== "All" && r.difficulty !== diff) return false;
      if (!query) return true;
      const hay = `${r.title} ${r.tagline} ${r.techStack.join(" ")} ${r.category}`.toLowerCase();
      return hay.includes(query) || query.split(" ").every((w) => hay.includes(w));
    });
  }, [q, cat, diff]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-12">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Discover projects</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Search {REELS.length}+ real engineering projects from students worldwide.
        </p>
      </header>

      <div className="sticky top-14 z-20 -mx-4 border-y border-border/60 bg-background/85 px-4 py-3 backdrop-blur md:top-0 md:mx-0 md:rounded-2xl md:border md:px-4">
        <div className="flex items-center gap-2">
          <div className="flex flex-1 items-center gap-2 rounded-full border border-border bg-card px-4 py-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search 'bus tracking', 'AI resume', 'crop disease'…"
              className="flex-1 bg-transparent text-sm outline-none"
            />
          </div>
          <button className="grid h-10 w-10 place-items-center rounded-full border border-border bg-card md:hidden" aria-label="Filters">
            <SlidersHorizontal className="h-4 w-4" />
          </button>
        </div>
        <div className="scrollbar-hide mt-3 flex gap-2 overflow-x-auto">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cn(
                "shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all",
                cat === c ? "gradient-brand border-transparent text-white shadow-glow" : "border-border bg-card hover:bg-accent",
              )}
            >
              {c}
            </button>
          ))}
          <span className="mx-1 h-6 w-px shrink-0 bg-border" />
          {DIFFICULTIES.map((d) => (
            <button
              key={d}
              onClick={() => setDiff(d)}
              className={cn(
                "shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all",
                diff === d ? "border-primary bg-primary/10 text-primary" : "border-border bg-card hover:bg-accent",
              )}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="mt-16 text-center">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-muted">
            <Search className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="mt-4 text-lg font-semibold">No projects match</h2>
          <p className="mt-1 text-sm text-muted-foreground">Try broadening your search or clearing filters.</p>
          <button
            onClick={() => {
              setQ("");
              setCat("All");
              setDiff("All");
            }}
            className="mt-4 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold hover:bg-accent"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <section className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((r) => (
            <Link
              key={r.id}
              to="/reels"
              className="group overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={r.poster}
                  alt={r.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute inset-x-3 bottom-3 flex items-center gap-2">
                  <span className="rounded-full gradient-brand px-2 py-1 text-[10px] font-bold text-white">
                    {r.difficulty}
                  </span>
                  <span className="rounded-full bg-black/50 px-2 py-1 text-[10px] font-medium text-white backdrop-blur">
                    {r.category}
                  </span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="line-clamp-1 text-base font-semibold">{r.title}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{r.tagline}</p>
                <div className="mt-3 flex flex-wrap gap-1">
                  {r.techStack.slice(0, 3).map((t) => (
                    <span key={t} className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium">
                      {t}
                    </span>
                  ))}
                </div>
                <div className="mt-3 flex items-center gap-3 border-t border-border/60 pt-3 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Heart className="h-3 w-3" /> {formatCount(r.stats.likes)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Bookmark className="h-3 w-3" /> {formatCount(r.stats.bookmarks)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye className="h-3 w-3" /> {formatCount(r.stats.views)}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </section>
      )}
    </div>
  );
}
