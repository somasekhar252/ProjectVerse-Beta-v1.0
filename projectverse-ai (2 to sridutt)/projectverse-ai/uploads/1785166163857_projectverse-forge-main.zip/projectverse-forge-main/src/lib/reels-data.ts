export type Reel = {
  id: string;
  title: string;
  tagline: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  techStack: string[];
  creator: {
    id: string;
    name: string;
    handle: string;
    college: string;
    branch: string;
    year: string;
    avatarColor: string;
  };
  videoUrl: string;
  poster: string;
  stats: { likes: number; comments: number; bookmarks: number; shares: number; views: number };
  duration: number;
  problem: string;
  solution: string;
  architecture: string;
  folderStructure: string;
  interviewQuestions: { q: string; a: string }[];
  quiz: {
    question: string;
    options: string[];
    correct: number;
    explanation: string;
    xp: number;
  };
  related: string[];
  githubUrl: string;
};

// Publicly hosted MP4 samples (Google's classic test bucket) — safe to use.
const V = (name: string) =>
  `https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/${name}.mp4`;

const P = (seed: string) =>
  `https://images.unsplash.com/${seed}?auto=format&fit=crop&w=800&q=70`;

export const REELS: Reel[] = [
  {
    id: "smart-bus-tracking",
    title: "Smart Bus Tracking System",
    tagline: "Real-time GPS + ETA prediction with ML",
    category: "IoT · Full Stack",
    difficulty: "Advanced",
    techStack: ["React Native", "Node.js", "MongoDB", "TensorFlow", "GPS API"],
    creator: {
      id: "u_arjun",
      name: "Arjun Verma",
      handle: "arjun.builds",
      college: "IIT Kharagpur",
      branch: "CSE",
      year: "3rd Year",
      avatarColor: "#7c3aed",
    },
    videoUrl: V("BigBuckBunny"),
    poster: P("photo-1544620347-c4fd4a3d5957"),
    stats: { likes: 12400, comments: 342, bookmarks: 1820, shares: 210, views: 89000 },
    duration: 62,
    problem:
      "College students waste 30+ minutes daily waiting for buses without knowing real-time location or ETA.",
    solution:
      "IoT-enabled GPS trackers on every bus stream location to a Node backend; an LSTM model predicts arrival times with 92% accuracy under traffic conditions.",
    architecture:
      "Devices (ESP32+GPS) → MQTT broker → Node.js ingest → MongoDB time-series → FastAPI ML service → React Native app via WebSocket.",
    folderStructure: `smart-bus-tracking/
├── mobile/                # React Native passenger app
│   ├── src/screens/
│   ├── src/components/
│   └── src/services/
├── api/                   # Node.js ingest + REST
│   ├── src/modules/buses/
│   ├── src/modules/routes/
│   └── src/mqtt/
├── ml/                    # FastAPI ETA predictor
│   ├── model/lstm.py
│   └── train/
├── firmware/              # ESP32 GPS tracker
└── infra/`,
    interviewQuestions: [
      {
        q: "Why LSTM over linear regression for ETA prediction?",
        a: "Bus arrival is sequential and non-linear — traffic, weather, and time-of-day compound over the route. LSTMs capture temporal dependencies that a linear model cannot.",
      },
      {
        q: "How do you handle GPS drift when a bus is idle at a stop?",
        a: "Snap-to-route with a Kalman filter and clamp velocity < 2 km/h to the nearest stop coordinate.",
      },
    ],
    quiz: {
      question: "Which protocol is best for ingesting frequent GPS pings from many buses?",
      options: ["HTTPS polling", "MQTT", "GraphQL subscriptions", "FTP"],
      correct: 1,
      explanation:
        "MQTT is a lightweight pub/sub protocol built for constrained IoT devices with unstable networks — much cheaper than repeated HTTPS.",
      xp: 25,
    },
    related: ["ev-monitoring", "traffic-optimizer"],
    githubUrl: "https://github.com/example/smart-bus-tracking",
  },
  {
    id: "ai-crop-disease",
    title: "AI Crop Disease Detector",
    tagline: "On-device CNN detects 38 crop diseases from a leaf photo",
    category: "AI · Mobile",
    difficulty: "Intermediate",
    techStack: ["Flutter", "TensorFlow Lite", "Python", "FastAPI"],
    creator: {
      id: "u_priya",
      name: "Priya Nair",
      handle: "priya.ai",
      college: "NIT Trichy",
      branch: "ECE",
      year: "Final Year",
      avatarColor: "#ec4899",
    },
    videoUrl: V("ElephantsDream"),
    poster: P("photo-1523348837708-15d4a09cfac2"),
    stats: { likes: 8930, comments: 187, bookmarks: 1120, shares: 340, views: 54000 },
    duration: 48,
    problem:
      "Rural farmers lose 30-50% of yield due to late disease detection. Agronomists are unreachable in remote regions.",
    solution:
      "A fine-tuned MobileNetV3 model quantized for on-device inference runs offline in a Flutter app; farmers photograph a leaf and get diagnosis + treatment in <500ms.",
    architecture:
      "Flutter app (TFLite runtime) → optional FastAPI cloud fallback for low-confidence samples → community DB for expert review.",
    folderStructure: `ai-crop-disease/
├── app/                   # Flutter mobile app
│   ├── lib/screens/
│   ├── lib/tflite/
│   └── assets/models/
├── training/              # Python training scripts
│   ├── notebooks/
│   └── dataset/
├── api/                   # FastAPI fallback
└── docs/`,
    interviewQuestions: [
      {
        q: "Why MobileNetV3 instead of ResNet-50?",
        a: "MobileNetV3 uses depthwise-separable convolutions and neural architecture search to hit ~95% of ResNet accuracy at ~1/10 the params — critical for on-device inference.",
      },
    ],
    quiz: {
      question: "Which technique reduces a TF model size the most without huge accuracy loss?",
      options: ["Random pruning", "Post-training quantization", "Data augmentation", "Higher learning rate"],
      correct: 1,
      explanation:
        "INT8 post-training quantization can reduce a float32 model by ~4x while typically losing <1% accuracy.",
      xp: 20,
    },
    related: ["smart-farm-iot", "plant-health-drone"],
    githubUrl: "https://github.com/example/ai-crop-disease",
  },
  {
    id: "college-lms",
    title: "College LMS with Live Coding",
    tagline: "Zoom-like classroom + collaborative code editor",
    category: "EdTech · Full Stack",
    difficulty: "Advanced",
    techStack: ["Next.js", "WebRTC", "Socket.io", "PostgreSQL", "Redis"],
    creator: {
      id: "u_kabir",
      name: "Kabir Shah",
      handle: "kabir.dev",
      college: "BITS Pilani",
      branch: "CSE",
      year: "3rd Year",
      avatarColor: "#0ea5e9",
    },
    videoUrl: V("ForBiggerBlazes"),
    poster: P("photo-1522202176988-66273c2fd55f"),
    stats: { likes: 15600, comments: 512, bookmarks: 2900, shares: 480, views: 120000 },
    duration: 74,
    problem:
      "Existing LMSs are boring PDF dumps. Live coding classes need instant screen share + collaborative editing — Zoom cannot do the second.",
    solution:
      "A WebRTC classroom with a Monaco-based multi-cursor editor over Yjs CRDT, letting the professor and students edit the same file live with sub-100ms sync.",
    architecture:
      "Next.js frontend → Socket.io signaling → WebRTC SFU (mediasoup) → Yjs CRDT over WebSocket → Postgres for persistence, Redis for presence.",
    folderStructure: `college-lms/
├── web/                   # Next.js
│   ├── src/app/classroom/
│   └── src/lib/editor/
├── signaling/             # Socket.io + mediasoup
├── crdt-server/           # Yjs relay
├── db/migrations/
└── infra/`,
    interviewQuestions: [
      {
        q: "Why CRDTs instead of OT for the editor?",
        a: "CRDTs are commutative and don't require a central authority to serialize operations — you can survive network partitions and merge later. OT needs a central server to transform ops in order.",
      },
    ],
    quiz: {
      question: "Which topology scales best for a 100-student classroom video call?",
      options: ["P2P mesh", "SFU (Selective Forwarding Unit)", "MCU (Mixing)", "Client-only"],
      correct: 1,
      explanation:
        "SFU forwards each publisher's stream to N subscribers without decoding, avoiding the O(N²) bandwidth of mesh or CPU cost of MCU.",
      xp: 30,
    },
    related: ["classroom-quiz", "live-collab-editor"],
    githubUrl: "https://github.com/example/college-lms",
  },
  {
    id: "ev-monitoring",
    title: "Electric Bus Health Dashboard",
    tagline: "Battery degradation & route efficiency for fleet ops",
    category: "IoT · Data",
    difficulty: "Intermediate",
    techStack: ["React", "TimescaleDB", "FastAPI", "Grafana"],
    creator: {
      id: "u_ishita",
      name: "Ishita Rao",
      handle: "ishita.data",
      college: "IIT Bombay",
      branch: "Mechanical",
      year: "Final Year",
      avatarColor: "#22c55e",
    },
    videoUrl: V("ForBiggerEscapes"),
    poster: P("photo-1593941707882-a5bac6861d75"),
    stats: { likes: 6320, comments: 92, bookmarks: 810, shares: 140, views: 41000 },
    duration: 55,
    problem:
      "EV bus fleets don't have visibility into cell-level battery health — one bad cell can strand a route.",
    solution:
      "CAN-bus data streams into TimescaleDB; anomaly-detection flags SOH drops per cell and predicts replacement 3 weeks in advance.",
    architecture:
      "Bus CAN → Edge gateway (Rust) → MQTT → FastAPI → TimescaleDB → React dashboard + Grafana alerts.",
    folderStructure: `ev-monitoring/
├── edge/                  # Rust CAN reader
├── ingest/                # FastAPI
├── web/                   # React ops dashboard
├── db/                    # Timescale schemas
└── alerts/`,
    interviewQuestions: [
      {
        q: "Why TimescaleDB over vanilla Postgres?",
        a: "Native hypertables partition by time so queries over recent windows hit tiny chunks; you get compression and continuous aggregates for free.",
      },
    ],
    quiz: {
      question: "Which metric best reflects battery long-term health?",
      options: ["Voltage at rest", "State of Health (SOH)", "Instant current", "Ambient temp"],
      correct: 1,
      explanation:
        "SOH compares current capacity to nameplate capacity — the direct measure of aging.",
      xp: 20,
    },
    related: ["smart-bus-tracking", "solar-microgrid"],
    githubUrl: "https://github.com/example/ev-monitoring",
  },
  {
    id: "resume-ai",
    title: "AI Resume Coach for Freshers",
    tagline: "Scores your resume against a JD in real time",
    category: "AI · SaaS",
    difficulty: "Beginner",
    techStack: ["Next.js", "OpenAI API", "Postgres", "Tailwind"],
    creator: {
      id: "u_meera",
      name: "Meera Iyer",
      handle: "meera.codes",
      college: "VIT Vellore",
      branch: "IT",
      year: "2nd Year",
      avatarColor: "#f59e0b",
    },
    videoUrl: V("SubaruOutbackOnStreetAndDirt"),
    poster: P("photo-1516321318423-f06f85e504b3"),
    stats: { likes: 4210, comments: 68, bookmarks: 620, shares: 95, views: 28000 },
    duration: 40,
    problem:
      "Freshers apply blindly and get filtered by ATS. There's no cheap tool that scores a resume against a specific JD.",
    solution:
      "Paste JD + upload PDF → LLM extracts required skills, matches against parsed resume, and returns a 0-100 score with 5 concrete rewrites.",
    architecture:
      "Next.js → API route → pdfjs parse → LLM call with structured JSON output → Postgres history.",
    folderStructure: `resume-ai/
├── app/
│   ├── (marketing)/
│   └── coach/
├── lib/pdf/
├── lib/ai/
└── prisma/`,
    interviewQuestions: [
      {
        q: "Why structured output over free-form?",
        a: "You get typed JSON you can render deterministically; free-form text forces brittle regex parsing.",
      },
    ],
    quiz: {
      question: "Best way to keep an LLM's response fields consistent?",
      options: ["Higher temperature", "JSON schema / structured output", "Longer prompts", "Ask twice"],
      correct: 1,
      explanation:
        "Structured output constrains generation to a schema so downstream code can trust the shape.",
      xp: 15,
    },
    related: ["interview-prep-ai", "college-portfolio"],
    githubUrl: "https://github.com/example/resume-ai",
  },
  {
    id: "safe-campus",
    title: "SafeCampus SOS Wearable",
    tagline: "One-press SOS with live location for students",
    category: "IoT · Safety",
    difficulty: "Intermediate",
    techStack: ["ESP32", "LoRaWAN", "React Native", "AWS IoT"],
    creator: {
      id: "u_ravi",
      name: "Ravi Menon",
      handle: "ravi.iot",
      college: "IIIT Hyderabad",
      branch: "ECE",
      year: "3rd Year",
      avatarColor: "#ef4444",
    },
    videoUrl: V("TearsOfSteel"),
    poster: P("photo-1573497019940-1c28c88b4f3e"),
    stats: { likes: 9540, comments: 220, bookmarks: 1440, shares: 380, views: 66000 },
    duration: 58,
    problem:
      "Campus emergencies happen where cell signal is weak — calling for help isn't reliable.",
    solution:
      "A tiny ESP32 wearable with a physical SOS button broadcasts location over LoRaWAN to campus gateways, reaching security in <3 seconds even without cellular.",
    architecture:
      "Wearable → LoRa gateway → AWS IoT Core → Lambda → security dashboard + push to guardian app.",
    folderStructure: `safe-campus/
├── firmware/              # ESP32 C++
├── gateway/               # Raspberry Pi LoRa
├── cloud/                 # Lambda handlers
└── mobile/                # Guardian app`,
    interviewQuestions: [
      {
        q: "Why LoRaWAN over Wi-Fi for this?",
        a: "LoRa reaches 2-10 km with a coin-cell for months; Wi-Fi needs an AP within ~50 m and drains a battery quickly.",
      },
    ],
    quiz: {
      question: "What tradeoff does LoRa make for its long range?",
      options: ["Lower bandwidth", "Higher power", "Higher cost", "Shorter battery"],
      correct: 0,
      explanation:
        "LoRa trades data rate for range and battery life — perfect for tiny payloads like coordinates.",
      xp: 20,
    },
    related: ["campus-nav", "smart-id-card"],
    githubUrl: "https://github.com/example/safe-campus",
  },
];

export function getReel(id: string) {
  return REELS.find((r) => r.id === id);
}
