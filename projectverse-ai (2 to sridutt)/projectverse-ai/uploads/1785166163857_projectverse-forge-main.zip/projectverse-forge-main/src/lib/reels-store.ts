import { useEffect, useState, useCallback } from "react";

type ReelInteractions = {
  likes: Record<string, boolean>;
  bookmarks: Record<string, boolean>;
  follows: Record<string, boolean>;
  hidden: Record<string, boolean>;
  xp: number;
  quizzesAnswered: Record<string, boolean>;
  badges: string[];
  lastReelIndex: number;
  muted: boolean;
};

const DEFAULT: ReelInteractions = {
  likes: {},
  bookmarks: {},
  follows: {},
  hidden: {},
  xp: 0,
  quizzesAnswered: {},
  badges: [],
  lastReelIndex: 0,
  muted: true,
};

const KEY = "pv-reels-state-v1";

// tiny pub-sub so all components stay in sync across the app
type Listener = (state: ReelInteractions) => void;
const listeners = new Set<Listener>();
let memoryState: ReelInteractions | null = null;

function readState(): ReelInteractions {
  if (memoryState) return memoryState;
  if (typeof window === "undefined") return DEFAULT;
  let next: ReelInteractions = DEFAULT;
  try {
    const raw = localStorage.getItem(KEY);
    next = raw ? { ...DEFAULT, ...JSON.parse(raw) } : DEFAULT;
  } catch {
    next = DEFAULT;
  }
  memoryState = next;
  return next;
}

function writeState(next: ReelInteractions) {
  memoryState = next;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {}
  }
  listeners.forEach((l) => l(next));
}

export function useReelsStore() {
  const [state, setState] = useState<ReelInteractions>(DEFAULT);

  useEffect(() => {
    setState(readState());
    const l: Listener = (s) => setState(s);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);

  const toggleLike = useCallback((id: string) => {
    const s = readState();
    writeState({ ...s, likes: { ...s.likes, [id]: !s.likes[id] } });
  }, []);

  const toggleBookmark = useCallback((id: string) => {
    const s = readState();
    writeState({ ...s, bookmarks: { ...s.bookmarks, [id]: !s.bookmarks[id] } });
  }, []);

  const toggleFollow = useCallback((creatorId: string) => {
    const s = readState();
    writeState({ ...s, follows: { ...s.follows, [creatorId]: !s.follows[creatorId] } });
  }, []);

  const hideReel = useCallback((id: string) => {
    const s = readState();
    writeState({ ...s, hidden: { ...s.hidden, [id]: true } });
  }, []);

  const awardQuizXP = useCallback((quizId: string, xp: number) => {
    const s = readState();
    if (s.quizzesAnswered[quizId]) return { newlyAwarded: false, badgeUnlocked: null as string | null };
    const nextXP = s.xp + xp;
    let badgeUnlocked: string | null = null;
    const badges = [...s.badges];
    if (nextXP >= 100 && !badges.includes("Quiz Rookie")) {
      badges.push("Quiz Rookie");
      badgeUnlocked = "Quiz Rookie";
    }
    if (nextXP >= 250 && !badges.includes("Learner")) {
      badges.push("Learner");
      badgeUnlocked = "Learner";
    }
    if (nextXP >= 500 && !badges.includes("Top Scholar")) {
      badges.push("Top Scholar");
      badgeUnlocked = "Top Scholar";
    }
    writeState({
      ...s,
      xp: nextXP,
      quizzesAnswered: { ...s.quizzesAnswered, [quizId]: true },
      badges,
    });
    return { newlyAwarded: true, badgeUnlocked };
  }, []);

  const setLastIndex = useCallback((i: number) => {
    const s = readState();
    if (s.lastReelIndex === i) return;
    writeState({ ...s, lastReelIndex: i });
  }, []);

  const setMuted = useCallback((m: boolean) => {
    const s = readState();
    writeState({ ...s, muted: m });
  }, []);

  return {
    ...state,
    toggleLike,
    toggleBookmark,
    toggleFollow,
    hideReel,
    awardQuizXP,
    setLastIndex,
    setMuted,
  };
}
